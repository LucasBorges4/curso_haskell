-- comentário 
-- rodar comando terminal :l hello.hs exemplo
-- usar ghci para rodar arquivo no terminal

hello = putStrLn "Hello!"

-- hello
