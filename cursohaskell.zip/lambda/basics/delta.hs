delta a b c = b**2 - 4*a*c

-- :t 2.5 4.0 delta

bhaskara :: Double -> Double -> Double -> [Double]
bhaskara a b c
    | d < 0 = []
    | d == 0 = [x']
    | otherwise = [x', x'']
    where
        d = delta a b c
        x' = (-b + sqrt d) / (2*a)
        x'' = (-b - sqrt d) / (2*a)
