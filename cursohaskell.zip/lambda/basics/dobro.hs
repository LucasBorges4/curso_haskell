dobro = (* 2)
