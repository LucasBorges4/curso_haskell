import Data.List (partition, lookup)

l :: [a] -> Int
l [] = 0
l (h:t) = 1 + l t

{-
l :: [a] -> [a]
l [] = []
l (h:t) = h : l t
-}
sum' :: [Int] -> Int
sum' [] = 0
sum' (h:t) = h + sum' t

foldr' :: (a-> b -> b) -> b -> [a] -> b
foldr' f z [] = z
foldr' f (h: t) = f h (foldr' f z t)

{-

-}

{-
foldr' (+) 0 [1, 2, 3] = (+) 1 (foldr' (+) 0 [2,3])
                       = 1 ((+) 2 (foldr' 0 (+) [3]))
                       = 1 ((+) 2 ((+) 3 (foldr'(+) 0 [])))
                       = (+) 1 ((+) 2 ((+) 3 0))
                       = (+) 1 ((+) 2 3)
                       = (+) 1 5
                       = 6
-}

filter' :: (a -> Bool) -> [a] -> [a]
filter' f [] = []
filter' f (h:t) = 
    if f h
        then h: filter' f t
        else filter' f t

map' :: (a -> b) -> [a] -> [b]
map' f [] = []
map' f (h:t) = f h : map' f t

{-
quicksort :: (Ord a) => [a] -> [a]
quicksort [] = []
quicksort (pivot: t) = quicksort lt ++ [pivot] ++ quicksort gt
    where lt = filter (< pivot) t
          gt = filter (>= pivot) t
-}

quicksort :: (Ord a) => [a] -> [a]
quicksort [] = []
quicksort (pivot: t) = quicksort lt ++ [pivot] ++ quicksort gt
    where (lt, gt) = partition (< pivot) t -- converte em tupla 'o partition' e depois dividimos a tupla em vetores de acordo com os pares ordenados


