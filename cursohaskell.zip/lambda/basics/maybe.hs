import Data.List (lookup)
import Data.Maybe

indiceLetra :: Char -> Int
indiceLetra c = fromMaybe 0 m
    --case m of
      --  Nothing -> 0
        --Just i -> i
    where m = lookup c (zip ['A' .. 'Z'] [1..])

lookupBy :: (a -> Bool) -> [a] -> Maybe a
lookupBy f [] = Nothing
lookupBy f (h:t) =
    if f h
        then Just h
        else lookupBy f t

-- lookupBy (\p -> isUpper (head p)) ["livro", "casa", "teste"]
-- elem :t elem, 200 `elem` [1 .. 200]